from django.apps import AppConfig


class FacultiesConfig(AppConfig):
    name = 'faculties'
